const btn_showsqli = document.getElementById("sqli_show");
const view_des = document.getElementById("description-sql");

btn_showsqli.addEventListener("click", () => {
  if (view_des.style.display == "none") {
    view_des.style.display = "block";
  } else {
    view_des.style.display = "none";
  }
  console.log(1);
});

const btn_showxss = document.getElementById("xss_show");
const view_desxss = document.getElementById("description-xss");

btn_showxss.addEventListener("click", () => {
  if (view_desxss.style.display = "none") {
    view_desxss.style.display = "block";
  } else {
    view_desxss.style.display = "none";
  }
  console.log(2);
});
